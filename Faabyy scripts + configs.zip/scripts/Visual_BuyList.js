w = 300; h = 50; SaveCurTime = 0; access = 1; alpha = 0; name1 = ""; name2 = ""; name3 = ""; name4 = ""; name5 = ""; allweapon1 = ""; allweapon2 = ""; allweapon3 = ""; allweapon4 = ""; allweapon5 = "";

if (Convar.GetString("cl_detail_max_sway") == 5){
	Cheat.PrintColor([255,255,255,255], ("["));
	Cheat.PrintColor([60,255,60,255], ("SCRIPT"));
	Cheat.PrintColor([255,255,255,255], ("] By")); 
	Cheat.PrintColor([255,60,60,255], (" Zero Two \n"));
	Convar.SetString ("cl_detail_max_sway", "5.1");
}
UI.AddSliderInt("X-pos", -45, Global.GetScreenSize()[0]);
UI.AddSliderInt("Y-pos", 0, Global.GetScreenSize()[1]);
UI.AddCheckbox("Hide after 10 seconds")

function draw(){
curTime = Globals.Curtime();

	if (access == 1){
		if (alpha != 255){
			alpha = alpha + 5;
		}
	}else{
		if (alpha != 0){
			alpha = alpha - 5;
		}
	}
	
	if (UI.GetValue("Script Items", "Hide after 10 seconds")){
		if (SaveCurTime < curTime){
			access = 0;
		}else{
			access = 1;
		}
	}else{
		access = 1;
	}

if (Entity.IsValid(Entity.GetLocalPlayer())){
	
	
	x = UI.GetValue("Script Items", "X-pos")
    y = UI.GetValue("Script Items", "Y-pos")
	
	Render.FilledRect( x + 45, y, w, h, [ 40, 40, 40, alpha ] );
	Render.FilledRect( x + 50, y + 7, w-11, h-12 , [ 19, 19, 19, alpha ] );
	Render.Rect( x + 50, y + 5, w-10, h-9, [ 50, 50, 50, alpha ] );
	var colors = HSVtoRGB(Global.Realtime() * 0.1, 1, 1);
	Render.GradientRect(x + 51, y + 6, w-12, 1, 1, [colors.g, colors.b, colors.r, alpha], [colors.r, colors.g, colors.b, alpha]);
	
	h = 50
	y_y = y + 16
	x_x = x + 145

	if (name1 != ""){
		Render.String( x_x - 93, y_y, 0, name1, [255, 255, 255, alpha], 1);
		if (allweapon1 != ""){
			Render.String( x_x, y_y, 0, allweapon1, [255, 255, 255, alpha], 5);
		}
	}
	if (name2 != ""){
		h = h + 25;
		Render.String( x_x - 93, y_y + 25, 0, name2, [255, 255, 255, alpha], 1);
		if (allweapon2 != ""){
			Render.String( x_x, y_y + 25, 0, allweapon2, [255, 255, 255, alpha], 5);
		}
	}
	if (name3 != ""){
		h = h + 25;
		Render.String( x_x - 93, y_y + 50, 0, name3, [255, 255, 255, alpha], 1);
		if (allweapon3 != ""){
			Render.String( x_x, y_y + 50, 0, allweapon3, [255, 255, 255, alpha], 5);
		}
	}
	if (name4 != ""){
		h = h + 25;
		Render.String( x_x - 93, y_y + 75, 0, name4, [255, 255, 255, alpha], 1);
		if (allweapon4 != ""){
			Render.String( x_x, y_y + 75, 0, allweapon4, [255, 255, 255, alpha], 5);
		}
	}
	if (name5 != ""){
		h = h + 25;
		Render.String( x_x - 93, y_y + 100, 0, name5, [255, 255, 255, alpha], 1);
		if (allweapon5 != ""){
			Render.String( x_x, y_y + 100, 0, allweapon5, [255, 255, 255, alpha], 5);
		}
	}
}
}

function BuyLogs(){
ent = Entity.GetName(Entity.GetEntityFromUserID(Event.GetInt('userid')));
team = Event.GetInt('team')
if (team != Entity.GetProp(Entity.GetLocalPlayer(), "CBaseEntity", "m_iTeamNum")) {
	if (name1 == ""){
		name1 = Entity.GetName(Entity.GetEntityFromUserID(Event.GetInt('userid')));
	}else{
		if ((name2 == "") && (name1 != ent)){
			name2 = ent;
		}
		if ((name3 == "") && (name2 != ent)){
			if (name1 != ent){
				name3 = ent;
			}			
		}
		if ((name4 == "") && (name3 != ent)){
			if ((name2 != ent) && (name1 != ent)){
				name4 = ent;
			}			
		}
		if ((name5 == "") && (name4 != ent)){
			if ((name3 != ent) && (name2 != ent)){
				if (name1 != ent){
					name5 = ent;
				}
			}			
		}
	}
	
	if (ent == name1){
		allweapon1 = allweapon1 + get_icon(Event.GetString('weapon'));
	}
	if (ent == name2){
		allweapon2 = allweapon2 + get_icon(Event.GetString('weapon'));
	}
	if (ent == name3){
		allweapon3 = allweapon3 + get_icon(Event.GetString('weapon'));
	}
	if (ent == name4){
		allweapon4 = allweapon4 + get_icon(Event.GetString('weapon'));
	}
	if (ent == name5){
		allweapon5 = allweapon5 + get_icon(Event.GetString('weapon'));
	}
}
}

function roundend(){
	name1 = "";
	name2 = "";
	name3 = "";
	name4 = "";
	name5 = "";
	allweapon1 = "";
	allweapon2 = "";
	allweapon3 = "";
	allweapon4 = "";
	allweapon5 = "";
}

function rountstart(){
	SaveCurTime = curTime + 10;
}

function HSVtoRGB(h, s, v)
{
    var r, g, b, i, f, p, q, t;

    i = Math.floor(h * 6);
    f = h * 6 - i;
    p = v * (1 - s);
    q = v * (1 - f * s);
    t = v * (1 - (1 - f) * s);

    switch (i % 6)
    {
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        case 5: r = v, g = p, b = q; break;
    }

    return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
}

function get_icon(a) {
    var letter = ""
    switch (a) {
        case "weapon_deagle":
            letter = "a"
            break
        case "weapon_elite":
            letter = "b"
            break
        case "weapon_fiveseven":
            letter = "c"
            break
        case "weapon_glock":
            letter = "d"
            break
        case "weapon_ak47":
            letter = "e"
            break
        case "weapon_aug":
            letter = "f"
            break
        case "weapon_awp":
            letter = "g"
            break
        case "weapon_famas":
            letter = "h"
            break
        case "weapon_m249":
            letter = "i"
            break
        case "weapon_g3sg1":
            letter = "j"
            break
        case "weapon_galilar":
            letter = "k"
            break
        case "weapon_m4a1":
            letter = "l"
            break
        case "weapon_m4a1_silencer":
            letter = "m"
            break
        case "weapon_mac10":
            letter = "n"
            break
        case "weapon_hkp2000":
            letter = "o"
            break
        case "weapon_mp5sd":
            letter = "p"
            break
        case "weapon_ump45":
            letter = "q"
            break
        case "weapon_xm1014":
            letter = "r"
            break
        case "weapon_bizon":
            letter = "s"
            break
        case "weapon_mag7":
            letter = "t"
            break
        case "weapon_negev":
            letter = "u"
            break
        case "weapon_sawedoff":
            letter = "v"
            break
        case "weapon_tec9":
            letter = "w"
            break
        case "weapon_taser":
            letter = "x"
            break
        case "weapon_p250":
            letter = "y"
            break
        case "weapon_mp7":
            letter = "z"
            break
        case "weapon_mp9":
            letter = "A"
            break
        case "weapon_nova":
            letter = "B"
            break
        case "weapon_p90":
            letter = "C"
            break
        case "weapon_scar20":
            letter = "D"
            break
        case "weapon_sg556":
            letter = "E"
            break
        case "weapon_ssg08":
            letter = "F"
            break
        case "weapon_flashbang":
            letter = "H"
            break
        case "weapon_hegrenade":
            letter = "I"
            break
        case "weapon_smokegrenade":
            letter = "J"
            break
        case "weapon_molotov":
            letter = "K"
            break
        case "weapon_decoy":
            letter = "L"
            break
        case "weapon_incgrenade":
            letter = "M"
            break
        case "weapon_usp_silencer":
            letter = "P"
            break
        case "weapon_cz75a":
            letter = "Q"
            break
        case "weapon_revolver":
            letter = "R"
            break
		case "item_assaultsuit":
			letter = "T"
			break
		case "item_kevlar":
			letter = "S"
			break
		case "item_defuser":
			letter = "U"
			break
        default:
            letter = ""
            break
    }
    return letter
}

Global.RegisterCallback("item_purchase", "BuyLogs");
Global.RegisterCallback('round_start', 'rountstart');
Global.RegisterCallback('round_end', 'roundend');
Global.RegisterCallback("Draw", "draw")