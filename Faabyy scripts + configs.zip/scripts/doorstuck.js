var flip = false;
var isInBuyzone = false;

function onEnterBuyzone() {
    var player = Entity.GetEntityFromUserID( Event.GetInt( "userid" ) );
    if ( !player ) return;
    if ( Entity.IsLocalPlayer( player ) ) {
        if ( Event.GetInt( "canbuy" ) ) {
            isInBuyzone = true;
        }
    }
};

function onExitBuyzone() {
    var player = Entity.GetEntityFromUserID( Event.GetInt( "userid" ) );
    if ( !player ) return;
    if ( Entity.IsLocalPlayer( player ) ) {
        isInBuyzone = false;
    }
};

function onClientDisconnect() {
    isInBuyzone = false
};

function onCreateMove() {
    if ( !Entity.GetLocalPlayer() ) return;
    if ( isInBuyzone ) return;
    
    if ( UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script Items", "[DOORSTUCK] Enable") ) {
        if ( flip ) {
            Global.ExecuteCommand( "+use" );
        } else {
            Global.ExecuteCommand( "-use" );
        }

        flip = !flip;
    }
}

function onDraw() {
    if ( !UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script Items", "[DOORSTUCK] Enable") ) {
        flip = false;
        Global.ExecuteCommand( "-use" );
    }
}


Global.RegisterCallback( "enter_buyzone", "onEnterBuyzone" );
Global.RegisterCallback( "exit_buyzone", "onExitBuyzone" );
Global.RegisterCallback( "client_disconnect", "onClientDisconnect" );
Global.RegisterCallback( "CreateMove", "onCreateMove" );
Global.RegisterCallback( "Draw", "onDraw" );
UI.AddHotkey( "[DOORSTUCK] Enable" );
