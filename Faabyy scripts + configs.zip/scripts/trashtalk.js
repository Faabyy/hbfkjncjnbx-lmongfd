﻿UI.AddCheckbox("premium trashtalk");
//Gay killsay territory yes
var normal_killsays = ["ez", "too fucking easy", "effortless", "easiest kill of my life",
    "retard blasted", "cleans?", "nice memesense retard", "hello mind explaining what happened there",
    "pounce out of your window disgusting tranny, you shouldnt exist in this world",
    "lmao ur so ugly irl like bro doesnt it hurt to live like that, btw you know you can just end it all",
    "ROFL NICE *DEAD* HHHHHHHHHHHHHHHHHH", "take the cooldown and let your team surr retard",
    "go take some estrogen tranny", "uid police here present your user identification number right now", "tranny holzed", "better buy the superior hack!",
    "whatcha shootin at retard", "nice 0.5x0.5m room you poorfag, how the fuck did you afford an acc hhhhhh", "imagine losing at video games couldn't ever be me", "але а противники то где???", "nice chromosome count you sell??",
    "nice thirdworldspeak ROFL"
];

var hs_killsays = ["ez", "effortless", "1", "nice antiaim, you sell?", "you pay for that?",
    "refund right now", "consider suicide", "bro are u clean?",
    "another retard blasted",
    "hhhhhhhhhhhhhhhhhh 1, you pay for that? refund so maybe youll afford some food for your family thirdworld monkey",
    "paster abandoned the match and received a 7 day competitive matchmaking cooldown",
    "freeqn.net/refund.php", "refund your rainbowhook right now pasteuser dog",
    "JAJAJAJJAJA NICE RAINBOWPASTE ROFL",
    "140er????", "get good get vantap4ik",
    "1 but all you need to fix your problems is a rope and a chair you ugly shit",
    "who (kto) are you (nn4ik) wattafak mens???????", "must be an uid issue", "holy shit consider refunding your trash paste rofl",
    "hello please refund your subpar product",
    "stop spending your lunch money on shitpastes retard",
    "thats going in my media compilation right there get shamed retard rofl",
    "imagine the only thing you eat being bullets man being a thirdworlder must suck rofl", "so fucking ez", "bot_kick", "where the enemies at????",
    "so fucking ez", "bot_kick", "where the enemies at????", "aimbot working?", "resolver be like: not today", "dude your cheat is off", "Legit config?", "You can fire weapons btw", "Hitchance 0 doesnt work man",
    "desync not available", "nice sideways", "Fanta User?", "Texashook is dead buddy", "Selfcoded paste?", "interesting uid issue", "Refund your Rainbow paste", "Aimjunkies 2020 be like", "Indigo still working? wow",
    "Do you have settings?", "Walmart Cheats?", "Aldi Cheats?", "Lidl cheats?", "Steering Wheel HvH, huh", "Controller User?", "Sad moment", "Where is your gaming chair?", "Feeling bad for you rn", "Got headshotted due to Paste"
];

//I hope you haven't gotten cancer after reading those

function on_player_death() {
    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "premium trashtalk")) {
        var victim = Entity.GetEntityFromUserID(Event.GetInt("userid"));
        var attacker = Entity.GetEntityFromUserID(Event.GetInt("attacker"));
        var headshot = Event.GetInt("headshot") == 1;

        if (Entity.IsLocalPlayer(attacker) && attacker != victim) {
            var normal_say = normal_killsays[Math.floor(Math.random() * normal_killsays.length)];
            var hs_say = hs_killsays[Math.floor(Math.random() * hs_killsays.length)];

            if (headshot && Math.floor(Math.random() * 3) <= 1) //gamer style randomizer
            {
                Cheat.ExecuteCommand("say " + hs_say);
                return;
            }
            Cheat.ExecuteCommand("say " + normal_say);
        }
    }
}

var killsay_amt = normal_killsays.length + hs_killsays.length;

Cheat.Print("trashtalk js loaded, killsay count: " + killsay_amt + "\n");
Cheat.RegisterCallback("player_death", "on_player_death");